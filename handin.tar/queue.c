/*
 * Código para diagnostico de conhecimento básico em C.
 * Desenvolvido para o curso CET-088, CET-082
 * Modificado por Leard Fernandes, 2017
 * Developed by R. E. Bryant, 2017
*/

 /*
  * Este programa implementa uma fila que suporta ambas as operações FIFO e LILO.
  *
  * Ele utiliza uma lista unicamente ligada para representar o conjunto de
  * elementos da fila
*/

#include <stdlib.h>
#include <stdio.h>

#include "harness.h"
#include "queue.h"

/*
  Cria uma fila vazia.
  Retorna NULL se o espaço na puder ser alocado.
*/
queue_t *q_new()
{
    queue_t *q =  malloc(sizeof(queue_t));
    /* E se malloc retornar NULL? */
    if (q == NULL)
    {
      return NULL;
    }
    
    q->head = NULL;
    q->tail = NULL;
    q->q_size = 0;
    return q;
}

/*  Libera todo o espaço utilizado pela fila. */
void q_free(queue_t *q)
{
    /* Como liberar os elementos da lista? */
    /* Libera a estrutura da fila */
	if (q == NULL)
    {
      return;
    }

    list_ele_t *auxFree, *previous;
    auxFree = q->head;
    while(auxFree != NULL)
    {	
    	previous = auxFree;
    	auxFree = auxFree->next;
    	free(previous);
    }
    free(q);
}

/*
  Tenta inserir o elemento na cabeça da fila.
  Retorna true se houve sucesso
  Retorna false se q é NULL ou não foi possível alocar espaço
*/
bool q_insert_head(queue_t *q, int v)
{
	if (q == NULL)
    {
      return false;
    }

    list_ele_t *newh;
    
    /* O que você deverá fazer se q é NULL ? */
    newh = malloc(sizeof(list_ele_t));
    if (newh == NULL)
    {
      return false;
    }
    
    newh->value = v;
    newh->next = q->head;
    q->head = newh;
    if (q->q_size == 0)
    {
      q->tail = newh;
    }
    q->q_size = q->q_size + 1;
    return true;
}


/*
  Tenta inserir o elemento na calda da fila.
  Retorna true se houve sucesso
  Retorna false se q é NULL ou não foi possível alocar espaço
*/
bool q_insert_tail(queue_t *q, int v)
{
    /* Você precisa escrever o código completo para esta função */
    /* lembre-se: Você deverá operar no tempo de O(1) */
    if (q == NULL)
    {
      return false;
    }

    list_ele_t *newTail;
    newTail = malloc(sizeof(list_ele_t));
    if (newTail == NULL)
    {
      return false;
    }

    newTail->value = v;
    newTail->next = NULL;
    if (q->q_size == 0)
    {
      q->head = newTail;
      q->tail = newTail;
    }
    //q->tail->next = newTail;
    if (q->q_size > 0)
    {
    	q->tail->next = newTail;
    	q->tail = newTail;
    }
    

    q->q_size = q->q_size + 1;
    return true;
}

/*
  Tenta remover o elemento na cabeça da fila.
  Retorna true se houve sucesso
  Retorna false se q é NULL ou vazia
  Se vp é não-NULL e o elemento removido, armazena o valor removido em *vp
  Qualquer armazenamento não utilizado deve ser liberado
*/
bool q_remove_head(queue_t *q, int *vp)
{
    if (q == NULL || q->head == NULL)
    {
      return false;
    }

    if (vp == NULL)
    {
    	return false;
    }


    list_ele_t *qAux;
    qAux = q->head;
    *vp = q->head->value;
    q->head = q->head->next;
    free(qAux);

    q->q_size = q->q_size - 1;
    
    /* Você precisa consertar este código. */
    return true;
}

/*
  Retorna o número de elementos na fila.
  Retorna 0 se q é NULL ou vazia
*/
int q_size(queue_t *q)
{
  /* Você precisa escrever o código completo para esta função */
  /* lembre-se: Você deverá operar no tempo de O(1) */
    if (q == NULL || q->q_size == 0)
    {
		return 0;
    }else{
    	return q->q_size;
    }
    
}

/*
  Inverte os elementos na fila.

  Sua implementação não dever alocar ou liberar quaisquer elementos (e.g., pela
  chamada de q_insert_head ou q_remove_head). Ao invés disso, ela deverá
  modificar os ponteiros na estrutura de dados existente.
*/
void q_reverse(queue_t *q)
{
	if (q == NULL || q->q_size == 0)
	{
		return;
	}

	if (q->q_size > 1)
	{
		list_ele_t *newHead;
	    list_ele_t *aux;
	    aux = q->head;
	    list_ele_t *previous = NULL;
	    list_ele_t *next = NULL;
	    list_ele_t *current = NULL;
	    q->tail = q->head;
	    // qHead = q->head;
	  
	    while(aux != NULL){
	      current = aux;
	      next = aux->next;
	      current->next = previous;
	      previous = current;
	      newHead = current;

	      aux = next;
	    }

	    q->head = newHead;
	}
    
    /* Você precisa escrever o código completo para esta função */
}
